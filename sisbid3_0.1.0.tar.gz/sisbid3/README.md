---
output:
  md_document:
    variant: markdown_github
---

<!-- README.md is generated from README.Rmd. Please edit that file -->



# sisbid3

The goal of sisbid3 is to illustrate the basics of package creation

## Example

This is a basic example which shows you how to solve a common problem: correcting the apprehension that package writing must be hard. 

