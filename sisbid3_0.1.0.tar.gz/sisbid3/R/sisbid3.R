#' Illustrates basic package construction
#'
#' This includes just a few functions, nothing fancy
#' It may also include data.
#'
#' @docType package
#' @name sisbid3
NULL
