#' A small basic dataset
#'
#' This is just an example to see if I can get
#' this to work
#'
#' @format A data frame with 5 rows and 2 columns
#' \describe{
#'   \item{basicDataX}{simulated X values}
#'   \item{basicDataY}{simulated Y values}
#' }
#' @source I made this up
"basicData"
